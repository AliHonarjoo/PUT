# version.py
__version__ = "0.1.1"
__version_info__ = (0, 1, 1)

def get_version():
    return __version__# version.py
__version__ = "0.1.1"
__version_info__ = (0, 1, 1)

def get_version():
    return __version__