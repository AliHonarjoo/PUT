# form-manager

A lightweight Flask + SQLite app implementing Forms (previously 'checklists') management.
This is a minimal implementation matching the requested features for the initial version.


.\venv\Scripts\activate
flask run