from functools import wraps
from flask import redirect, url_for, flash
from flask_login import current_user

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "admin":
            flash("شما اجازه دسترسی به این صفحه را ندارید.", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def filler_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "filler":
            flash("دسترسی به این صفحه فقط برای پرکننده‌ها مجاز است.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

def viewer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "viewer":
            flash("شما اجازه مشاهده این بخش را ندارید.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function
