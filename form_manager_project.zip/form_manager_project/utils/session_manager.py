# utils/session_manager.py
from flask import session
from models import User  # حتماً اضافه کن!

def login_user(u):
    session['user_id'] = u.id
    session['role'] = u.role
    session['username'] = u.username

def logout_user():
    session.pop('user_id', None)
    session.pop('role', None)
    session.pop('username', None)

def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return User.query.get(uid)