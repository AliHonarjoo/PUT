# utils/decorators.py
from functools import wraps
from flask import flash, redirect, url_for
from .session_manager import current_user  # از session_manager

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = current_user()
        if not user or user.role != 'admin':
            flash('دسترسی ادمین لازم است.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated

def filler_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = current_user()
        if not user or user.role != 'filler':
            flash('دسترسی غیرمجاز.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated

def viewer_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = current_user()
        if not user or user.role != 'viewer':
            flash('دسترسی غیرمجاز.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated