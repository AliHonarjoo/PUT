from app import app, db

# ساخت دیتابیس داخل context برنامه Flask
with app.app_context():
    db.create_all()
    print("✅ Database created successfully!")
