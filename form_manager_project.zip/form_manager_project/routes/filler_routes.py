from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import Form, FormItem, FormResponse, UserForm
from utils.decorators import filler_required, current_user
from extensions import db
from datetime import datetime
import uuid

# تعریف Blueprint با prefix مشخص
filler_bp = Blueprint('filler', __name__, url_prefix='/filler')

@filler_bp.route('/forms')
@filler_required
def forms():
    user_id = session.get('user_id')
    if not user_id:
        flash('ابتدا وارد شوید.', 'warning')
        return redirect(url_for('auth.login'))
    
    # فرم‌هایی که به این کاربر اختصاص داده شده
    assigned = UserForm.query.filter_by(user_id=user_id).all()
    form_ids = [a.form_id for a in assigned]
    forms = Form.query.filter(Form.id.in_(form_ids)).all() if form_ids else []

    return render_template('filler_forms.html', forms=forms)

@filler_bp.route('/form/<int:form_id>', methods=['GET','POST'])
@filler_required
def form_fill(form_id):
    form = Form.query.get_or_404(form_id)
    u = current_user()

    # بررسی اینکه آیا این کاربر مجاز به پر کردن فرم هست
    if not UserForm.query.filter_by(user_id=u.id, form_id=form.id).first():
        flash('به این فرم دسترسی ندارید', 'danger')
        return redirect(url_for('filler.forms'))
    
     # جدا کردن تیترها از آیتم‌ها
    hdrs = [it.text.replace('__hdr__:', '') for it in form.items if it.text.startswith('__hdr__:')]
    items = [it for it in form.items if not it.text.startswith('__hdr__:')]

    if request.method=='POST':
        session_id = str(uuid.uuid4())
        timestamp = datetime.utcnow()

        for it in items:
            val = request.form.get(f'item_{it.id}')
            if val:
                db.session.add(FormResponse(user_id=u.id, item_id=it.id, answer=val, created_at=timestamp, session_id=session_id))
        db.session.commit()
        flash('پاسخ‌ها ذخیره شد', 'success')
        return redirect(url_for('filler.forms'))
    return render_template('filler_form_fill.html', form=form, headers=hdrs, items=items)
