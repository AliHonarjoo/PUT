from flask import Blueprint, render_template, request
from models import Form, FormResponse, UserForm, User
from utils.decorators import viewer_required, current_user

viewer_bp = Blueprint('viewer', __name__, url_prefix='/viewer')

@viewer_bp.route('/forms')
def forms():
    u = current_user()
    if u and u.role=='admin':
        forms = Form.query.order_by(Form.id.desc()).all()
    elif u:
        assigned = UserForm.query.filter_by(user_id=u.id).all()
        ids = [a.form_id for a in assigned]
        forms = Form.query.filter(Form.id.in_(ids)).all() if ids else []
    else:
        forms = []
    return render_template('viewer_forms.html', forms=forms)



@viewer_bp.route('/forms/<int:form_id>')
def form_filled_list(form_id):
    form = Form.query.get_or_404(form_id)
    item_ids = [i.id for i in form.items if not i.text.startswith('__hdr__:')]

    # همه پاسخ‌های این فرم، بر اساس تاریخ نزولی
    responses = FormResponse.query.filter(FormResponse.item_id.in_(item_ids)) \
                                  .order_by(FormResponse.created_at.desc()) \
                                  .all()

    # گروه‌بندی بر اساس سری پر کردن (هر بار پر کردن را با timestamp جدا می‌کنیم)
    grouped = {}
    for r in responses:
        grouped.setdefault((r.user_id, r.session_id), []).append(r)

    # ساخت لیست برای نمایش در جدول
    rows = []
    for (uid, timestamp), resp_list in grouped.items():
        u = User.query.get(uid)
        timestamp = resp_list[0].created_at.strftime('%Y-%m-%d %H:%M:%S')
        rows.append({
            'user': u,
            'timestamp': timestamp,
            'session_id': resp_list[0].session_id,
            'responses': resp_list
        })

    # مرتب‌سازی بر اساس زمان
    rows.sort(key=lambda x: x['timestamp'], reverse=True)

    # صفحه‌بندی دستی (10 تا 10 تا)
    page = int(request.args.get('page', 1))
    per_page = 10
    total = len(rows)
    start = (page - 1) * per_page
    end = start + per_page
    page_rows = rows[start:end]
    has_next = end < total
    has_prev = start > 0

    return render_template('viewer_form_filled_list.html',
                           form=form,
                           rows=page_rows,
                           page=page,
                           has_next=has_next,
                           has_prev=has_prev)


@viewer_bp.route('/forms/<int:form_id>/view/<int:user_id>/<session_id>')
def form_view_one(form_id, user_id, session_id):
    form = Form.query.get_or_404(form_id)
    items = [it for it in form.items if not it.text.startswith('__hdr__:')]
    user = User.query.get_or_404(user_id)
    resp_map = {r.item_id: r for r in FormResponse.query.filter_by(user_id=user.id, session_id=session_id).all()}
    return render_template('viewer_form_view.html', form=form, user=user, items=items, resp_map=resp_map)
