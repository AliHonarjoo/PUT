from flask import render_template, redirect, url_for, flash
from forms.settings_form import SettingsForm
from utils.decorators import filler_required

@admin_bp.route('/settings', methods=['GET', 'POST'])
def settings():
    form = SettingsForm()
    if form.validate_on_submit():
        site_name = form.site_name.data
        admin_email = form.admin_email.data
        enable_notifications = form.enable_notifications.data
        
        # ذخیره در دیتابیس یا فایل config
        flash("تنظیمات با موفقیت ذخیره شد ✅", "success")
        return redirect(url_for('admin.settings'))

    return render_template('admin/settings.html', form=form)