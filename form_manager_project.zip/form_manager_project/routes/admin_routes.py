from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from extensions import db
from models import User, Form, FormItem, Setting, UserForm
from utils.decorators import admin_required, current_user  # ایمپورت شد!
from datetime import datetime
from flask_login import login_required, current_user
import uuid

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

'''@admin_bp.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']

        # پیدا کردن کاربر (هر نقشی که باشه)
        user = User.query.filter_by(username=username).first()

        # بررسی رمز عبور
        if user and user.check_password(password):
            # ورود کاربر با flask-login
            login_user(user)

            # ذخیره اطلاعات اضافه در session (اختیاری)
            session['role'] = user.role
            session['username'] = user.username


            flash(f'خوش آمدی {user.username} 👋', 'success')

            # هدایت بر اساس نقش
            if user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            elif user.role == 'filler':
                return redirect(url_for('filler_forms'))
            elif user.role == 'viewer':
                return redirect(url_for('viewer_forms'))
            else:
                flash('نقش کاربر معتبر نیست', 'danger')
                return redirect(url_for('auth.login'))
        else:    
            flash('نام کاربری یا رمز عبور اشتباه است', 'danger')

    return render_template('login.html')


@admin_bp.route('/logout')
def logout():
    # پاک کردن کامل سشن
    session.clear()
    flash('خروج انجام شد', 'info')
    return redirect(url_for('admin_login'))'''


@admin_bp.route('/dashboard')
@login_required
def dashboard():
    # بررسی نقش برای جلوگیری از لوپ
    if session.get('role') != 'admin':
        flash('دسترسی غیرمجاز ❌', 'danger')
        return redirect(url_for('auth.login'))

    return render_template('admin_dashboard.html')


@admin_bp.route('/create_user', methods=['GET','POST'])
@admin_required
def create_user():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        role = request.form['role']
        if not username or not password or role not in ('admin','filler','viewer'):
            flash('فیلدها را کامل کنید', 'danger')
            return redirect(url_for('admin.create_user'))
        if User.query.filter_by(username=username).first():
            flash('نام کاربری موجود است', 'warning')
            return redirect(url_for('admin.create_user'))
        u = User(username=username, role=role)
        u.set_password(password)
        db.session.add(u)
        db.session.commit()
        flash('کاربر ایجاد شد', 'success')
        return redirect(url_for('admin.list_users'))
    return render_template('create_user.html')


@admin_bp.route('/list_users')
@admin_required
def list_users():
    users = User.query.order_by(User.id.desc()).all()
    return render_template('list_users.html', users=users)


@admin_bp.route('/edit_user/<int:user_id>', methods=['GET','POST'])
@admin_required
def edit_user(user_id):
    u = User.query.get_or_404(user_id)
    if request.method == 'POST':
        if 'delete' in request.form:
            db.session.delete(u)
            db.session.commit()
            flash('کاربر حذف شد', 'success')
            return redirect(url_for('admin.list_users'))
        role = request.form.get('role')
        pw = request.form.get('password')
        if role in ('admin','filler','viewer'):
            u.role = role
        if pw:
            u.set_password(pw)
        db.session.commit()
        flash('کاربر بروزرسانی شد', 'success')
        return redirect(url_for('admin.list_users'))
    return render_template('edit_user.html', user=u)


@admin_bp.route('/create_form', methods=['GET','POST'])
@admin_required
def create_form():
    if request.method == 'POST':
        name = request.form.get('name','').strip()
        header1 = request.form.get('header1','سوال').strip()
        header2 = request.form.get('header2','بله').strip()
        header3 = request.form.get('header3','خیر').strip()
        items = request.form.getlist('item')
        if not name:
            flash('نام فرم را وارد کنید', 'danger')
            return redirect(url_for('admin.create_form'))
        f = Form(name=name, created_by=session.get('user_id'))
        db.session.add(f)
        db.session.commit()
        db.session.add(FormItem(form_id=f.id, text='__hdr__:'+header1))
        db.session.add(FormItem(form_id=f.id, text='__hdr__:'+header2))
        db.session.add(FormItem(form_id=f.id, text='__hdr__:'+header3))
        for it in items:
            if it.strip():
                db.session.add(FormItem(form_id=f.id, text=it.strip()))
        db.session.commit()
        flash('فرم ساخته شد', 'success')
        return redirect(url_for('admin.view_forms'))
    return render_template('create_form.html')


@admin_bp.route('/view_forms')
@admin_required
def view_forms():
    forms = Form.query.order_by(Form.id.desc()).all()
    form_data = []
    for f in forms:
        creator = User.query.get(f.created_by) if f.created_by else None
        item_count = FormItem.query.filter_by(form_id=f.id).count()
        form_data.append({'id':f.id,'name':f.name,'item_count':item_count,'creator':creator.username if creator else 'نامشخص'})
    return render_template('view_forms.html', forms=form_data)


@admin_bp.route('/assign_form', methods=['GET','POST'])
@admin_required
def assign_form():
    users = User.query.filter(User.role != 'admin').all()
    forms = Form.query.all()
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        form_id = request.form.get('form_id')
        if not user_id or not form_id:
            flash('انتخاب کنید', 'danger')
            return redirect(url_for('admin.assign_form'))
        existing = UserForm.query.filter_by(user_id=user_id, form_id=form_id).first()
        if existing:
            flash('قبلا تخصیص داده شده', 'warning')
        else:
            db.session.add(UserForm(user_id=user_id, form_id=form_id))
            db.session.commit()
            flash('تخصیص انجام شد', 'success')
        return redirect(url_for('admin.assign_form'))
    return render_template('assign_form.html', users=users, forms=forms)



@admin_bp.route('/view_forms_items/<int:form_id>')
@admin_required
def view_forms_items(form_id):
    form = Form.query.get_or_404(form_id)
    creator = User.query.get(form.created_by) if form.created_by else None
    return render_template('view_forms_items.html', form=form, creator=creator)


@admin_bp.route('/delete_form/<int:form_id>', methods=['POST'])
@admin_required
def delete_form(form_id):
    form = Form.query.get_or_404(form_id)
    FormItem.query.filter_by(form_id=form.id).delete()
    db.session.delete(form)
    db.session.commit()
    flash('فرم حذف شد', 'success')
    return redirect(url_for('admin.view_forms'))


@admin_bp.route('/settings', methods=['GET', 'POST'])
@admin_required
def settings():
    form = SettingsForm()

    # خواندن تنظیمات موجود از DB
    site_name_setting = Setting.query.filter_by(key='site_name').first()
    notif_setting = Setting.query.filter_by(key='enable_notifications').first()

    if request.method == 'GET':
        if site_name_setting:
            form.site_name.data = site_name_setting.value
        if notif_setting:
            form.enable_notifications.data = notif_setting.value == 'True'

    if form.validate_on_submit():
        if not site_name_setting:
            site_name_setting = Setting(key='site_name')
            db.session.add(site_name_setting)
        site_name_setting.value = form.site_name.data

        if not notif_setting:
            notif_setting = Setting(key='enable_notifications')
            db.session.add(notif_setting)
        notif_setting.value = str(form.enable_notifications.data)

        db.session.commit()
        flash('تنظیمات با موفقیت ذخیره شد.', 'success')
        return redirect(url_for('admin.settings'))

    return render_template('admin_settings.html', form=form)
