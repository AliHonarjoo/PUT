# routes/auth_routes.py
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import User
from extensions import db
from utils.session_manager import login_user, logout_user, current_user  # اضافه شد

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user() and session.get('role'):
        role = session.get('role')
        if role == 'admin':
            return redirect(url_for('admin.dashboard'))
        elif role == 'filler':
            return redirect(url_for('filler.forms'))
        elif role == 'viewer':
            return redirect(url_for('viewer.forms'))

    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']

        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)  # فقط session
            flash(f'خوش آمدی {user.username}', 'success')

            if user.role == 'admin':
                return redirect(url_for('admin.dashboard'))
            elif user.role == 'filler':
                return redirect(url_for('filler.forms'))
            elif user.role == 'viewer':
                return redirect(url_for('viewer.forms'))
        else:
            flash('نام کاربری یا رمز عبور اشتباه است.', 'danger')

    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    logout_user()
    flash('خروج با موفقیت انجام شد', 'info')
    return redirect(url_for('auth.login'))