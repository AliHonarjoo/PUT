import sqlite3

db_path = "instance/forms.db"

with sqlite3.connect(db_path) as conn:
    cursor = conn.cursor()

    # اضافه کردن ستون‌ها اگر وجود ندارند
    columns_to_add = {
        "form_id": "INTEGER",
        "item_id": "INTEGER",
        "answer": "TEXT",
        "created_at": "DATETIME",
        "session_id": "TEXT",
        "submitted_at": "DATETIME"
    }

    for column, col_type in columns_to_add.items():
        try:
            cursor.execute(f"ALTER TABLE form_response ADD COLUMN {column} {col_type}")
            print(f"✅ ستون '{column}' اضافه شد.")
        except sqlite3.OperationalError:
            print(f"ℹ️ ستون '{column}' از قبل وجود دارد.")

    conn.commit()
