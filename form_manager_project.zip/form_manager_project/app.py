from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Email
from extensions import db
from flask_login import login_user, UserMixin, current_user, login_required, LoginManager
import click, os, uuid
from datetime import datetime
from models import User, Form, FormItem, FormResponse, Setting, UserForm
from extensions import db, login_manager

from routes.auth_routes import auth_bp
from routes.admin_routes import admin_bp
from routes.filler_routes import filler_bp
from routes.viewer_routes import viewer_bp



app = Flask(__name__, instance_relative_config=True)

# --- تنظیمات مسیر دیتابیس ---
basedir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(basedir, 'instance')
if not os.path.exists(db_path):
    os.makedirs(db_path)  # اگر پوشه وجود نداشت بسازش

# --- App settings ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(db_path, 'forms.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY','dev-secret-key')

# --- مقداردهی دیتابیس ---
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'  # اسم view مربوط به صفحه‌ی لاگین
login_manager.login_message = "برای دسترسی ابتدا وارد شوید."

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.context_processor
def inject_now():
    return {'now': datetime.now,
            'user_country': session.get('country', 'AZ')  # یا از دیتابیس بگیر
            }

class SettingsForm(FlaskForm):
    site_name = StringField('نام سایت', validators=[DataRequired()])
    admin_email = StringField('ایمیل مدیر', validators=[DataRequired(), Email()])
    enable_notifications = BooleanField('فعال‌سازی اعلان‌ها')
    submit = SubmitField('ذخیره تنظیمات')

@app.cli.command('init-db')
def init_db():
    os.makedirs('instance', exist_ok=True)
    db.create_all()
    click.echo('Database initialized')

@app.cli.command('create-super')
@click.option('--username', prompt=True)
@click.option('--password', prompt=True, hide_input=True, confirmation_prompt=True)
def create_super(username, password):
    if User.query.filter_by(username=username).first():
        click.echo('User already exists')
        return
    u = User(username=username, role='admin')
    u.set_password(password)
    db.session.add(u)
    db.session.commit()
    click.echo(f'Created admin {username}')

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp, url_prefix="/admin")
app.register_blueprint(filler_bp, url_prefix="/filler")
app.register_blueprint(viewer_bp, url_prefix="/viewer")



if __name__=='__main__':
    app.run(debug=True)