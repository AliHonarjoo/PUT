from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField, BooleanField, RadioField
from wtforms.validators import DataRequired, Length, EqualTo

class LoginForm(FlaskForm):
    username = StringField("نام کاربری", validators=[DataRequired(), Length(min=3, max=25)])
    password = PasswordField("رمز عبور", validators=[DataRequired()])
    submit = SubmitField("ورود")

class CreateUserForm(FlaskForm):
    username = StringField("نام کاربری", validators=[DataRequired(), Length(min=3, max=25)])
    password = PasswordField("رمز عبور", validators=[DataRequired(), Length(min=4)])
    confirm_password = PasswordField("تکرار رمز عبور", validators=[DataRequired(), EqualTo('password', message="رمزها یکسان نیستند")])
    role = SelectField("نقش کاربر", choices=[("admin", "مدیر"), ("filler", "پرکننده فرم"), ("viewer", "مشاهده‌کننده")])
    submit = SubmitField("ایجاد کاربر")

class CreateFormForm(FlaskForm):
    name = StringField("نام فرم", validators=[DataRequired()])
    description = TextAreaField("توضیحات فرم")
    submit = SubmitField("ایجاد فرم")

class AddItemForm(FlaskForm):
    text = StringField("متن سوال", validators=[DataRequired()])
    submit = SubmitField("افزودن سوال")
