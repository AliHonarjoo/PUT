from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db

# -------------------------
# مدل کاربر
# -------------------------

class User(UserMixin, db.Model):
    __tablename__ = "user"
    __table_args__ = {'extend_existing': True}

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="filler")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # متدهای رمز عبور امن
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f"<User {self.username}>"

# -------------------------
# مدل فرم
# -------------------------

class Form(db.Model):
    __tablename__ = "form"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"))
    created_at = db.Column(db.DateTime, default=datetime.utcnow())

    items = db.relationship("FormItem", backref="form", cascade="all, delete-orphan")
    responses = db.relationship("FormResponse", backref="form", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Form {self.name}>"

# -------------------------
# مدل آیتم‌های فرم
# -------------------------
class FormItem(db.Model):
    __tablename__ = "form_item"

    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(255), nullable=False)
    form_id = db.Column(db.Integer, db.ForeignKey("form.id"), nullable=False)

# -------------------------
# مدل پاسخ‌های فرم
# -------------------------
class FormResponse(db.Model):
    __tablename__ = "form_response"

    id = db.Column(db.Integer, primary_key=True)
    form_id = db.Column(db.Integer, db.ForeignKey("form.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    # این‌ها رو اضافه کن تا کد app.py بدون ارور کار کنه:
    item_id = db.Column(db.Integer, db.ForeignKey("form_item.id"))
    answer = db.Column(db.String)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    session_id = db.Column(db.String)

    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)

    answers = db.relationship("FormAnswer", backref="response", cascade="all, delete-orphan")

# -------------------------
# مدل پاسخ هر آیتم
# -------------------------
class FormAnswer(db.Model):
    __tablename__ = "form_answer"

    id = db.Column(db.Integer, primary_key=True)
    response_id = db.Column(db.Integer, db.ForeignKey("form_response.id"), nullable=False)
    item_id = db.Column(db.Integer, db.ForeignKey("form_item.id"), nullable=False)
    answer = db.Column(db.String(10))  # 'yes' یا 'no'

# -------------------------
# مدل تنظیمات سایت
# -------------------------
class Setting(db.Model):
    __tablename__ = "setting"

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.String(255), nullable=True)

    def __repr__(self):
        return f"<Setting {self.key}={self.value}>"

class UserForm(db.Model):
    __tablename__ = 'user_form'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    form_id = db.Column(db.Integer, db.ForeignKey('form.id'), nullable=False)